# Contributing to NexusAGI

Thank you for your interest in contributing to NexusAGI! This document provides guidelines and instructions for contributing.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Documentation](#documentation)

## Code of Conduct

This project and everyone participating in it is governed by our Code of Conduct. By participating, you are expected to uphold this code.

## How Can I Contribute?

### 🐛 Reporting Bugs

Before creating bug reports, please check existing issues as you might find out that you don't need to create one. When you are creating a bug report, please include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples to demonstrate the steps**
- **Describe the behavior you observed and what you expected**
- **Include screenshots if applicable**

### 💡 Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, please include:

- **Use a clear and descriptive title**
- **Provide a detailed description of the suggested enhancement**
- **Explain why this enhancement would be useful**
- **List some other AGI systems where this enhancement exists**

### 🔧 Pull Requests

- Fill in the required template
- Do not include issue numbers in the PR title
- Include screenshots and animated GIFs in your pull request whenever possible
- Follow the [Python](#coding-standards) style guide
- Include thoughtfully-worded, well-structured tests
- Document new code
- End all files with a newline

## Development Setup

### Prerequisites

- Python 3.13 or higher
- Git
- pip

### Setup Steps

1. **Fork the repository**
   ```bash
   # Click the Fork button on GitHub
   ```

2. **Clone your fork**
   ```bash
   git clone https://github.com/YOUR_USERNAME/NexusAGI.git
   cd NexusAGI
   ```

3. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

4. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-dev.txt
   ```

5. **Create a branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

6. **Make your changes and test**
   ```bash
   pytest tests/
   ```

7. **Commit your changes**
   ```bash
   git add .
   git commit -m "Add: your feature description"
   ```

8. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

9. **Create a Pull Request**

## Pull Request Process

1. Update the README.md with details of changes if applicable
2. Update the CHANGELOG.md with a note describing your changes
3. The PR will be merged once you have the sign-off of at least one maintainer

### PR Title Format

Use the following format for PR titles:

```
<type>: <description>

Types:
- feat: A new feature
- fix: A bug fix
- docs: Documentation only changes
- style: Changes that do not affect the meaning of the code
- refactor: A code change that neither fixes a bug nor adds a feature
- perf: A code change that improves performance
- test: Adding missing tests
- chore: Changes to the build process or auxiliary tools

Example:
feat: Add new domain module for legal consulting
```

## Coding Standards

### Python Style Guide

We follow [PEP 8](https://peps.python.org/pep-0008/) with some modifications:

- **Line length:** 120 characters (not 79)
- **Quotes:** Use double quotes for docstrings, single or double for strings
- **Imports:** Group imports (standard library, third-party, local)

### Code Formatting

We use [Black](https://github.com/psf/black) for code formatting:

```bash
black core/ tests/ main.py
```

### Type Hints

Use type hints for all public functions:

```python
def process_input(user_input: str, context: Optional[Dict] = None) -> Dict[str, Any]:
    """Process user input and return response."""
    pass
```

### Docstrings

Use Google-style docstrings:

```python
def function_name(param1: str, param2: int) -> bool:
    """Short description of function.

    Longer description if needed.

    Args:
        param1: Description of param1
        param2: Description of param2

    Returns:
        Description of return value

    Raises:
        ValueError: When something is wrong
    """
    pass
```

## Testing Guidelines

### Writing Tests

- Write tests for all new features
- Write tests for bug fixes
- Use descriptive test names
- Test edge cases

### Test Structure

```python
class TestFeatureName:
    """Test suite for FeatureName."""

    def test_basic_functionality(self):
        """Test that basic functionality works."""
        # Arrange
        input_data = "test"
        
        # Act
        result = feature_function(input_data)
        
        # Assert
        assert result == expected_output

    def test_edge_case(self):
        """Test edge case handling."""
        # Test with empty input
        result = feature_function("")
        assert result is None
```

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest --cov=core --cov-report=html

# Run specific test file
pytest tests/test_feature.py -v

# Run specific test
pytest tests/test_feature.py::TestFeature::test_method -v
```

## Documentation

### Code Documentation

- Add docstrings to all public classes and functions
- Keep comments up-to-date with code changes
- Use inline comments for complex logic

### README Updates

When adding new features:
- Update the feature list
- Add usage examples
- Update configuration options

### API Documentation

When adding new API endpoints:
- Document the endpoint in API Reference
- Include request/response examples
- Document error codes

## Adding New Domain Modules

To add a new domain:

1. **Create domain configuration**
   ```python
   DomainConfig(
       name="your_domain",
       display_name="Your Domain",
       description="Description of domain",
       keywords=["keyword1", "keyword2"],
       response_style="professional",
       specializations=["spec1", "spec2"]
   )
   ```

2. **Add knowledge base**
   ```
   data/domains/your_domain/knowledge.json
   ```

3. **Add tests**
   ```
   tests/test_your_domain.py
   ```

4. **Update documentation**
   - Add to README.md
   - Add to docs/domains.md

## Questions?

If you have questions, please:
- Check existing documentation
- Search existing issues
- Create a new issue with the "question" label

Thank you for contributing to NexusAGI! 🎉